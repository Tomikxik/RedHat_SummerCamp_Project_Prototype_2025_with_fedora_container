class Enemy():
    def __init__(self,health_points,attack_damage):
        self.hp = health_points
        self.atk = attack_damage
        #could be added more if its needed like type of defense or smth