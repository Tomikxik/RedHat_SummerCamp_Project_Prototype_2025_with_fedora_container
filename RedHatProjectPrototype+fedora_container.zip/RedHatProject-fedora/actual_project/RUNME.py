from main import Window

Window()